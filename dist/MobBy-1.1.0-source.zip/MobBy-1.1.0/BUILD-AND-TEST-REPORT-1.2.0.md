# MobBy 1.2.0 — build and test report

Date: 2026-11-18
Artifact under test: `MobBy-1.2.0.jar`
SHA-256: `a92afb6905c6b02139326338969b9e3ba18f347cfb46f050de51ec05ee8a30fd`

This report covers what was actually built and executed in the workspace. It separates checks that
passed from checks that were not run.

## Environment

| Item | Value |
|---|---|
| OS | Ubuntu 24.04 (cloud workspace) |
| JDK for build/tests | Eclipse Temurin 21.0.13+9 (LTS), `JAVA_HOME=~/jdk21` |
| Gradle | Wrapper 9.9.1 (`./gradlew`) |
| Plugin target | Paper API 1.20.6, Java 21 bytecode |
| Integration server | Paper **26.3 build 253** (`26.3.build.253-stable`), Java 25 |
| Integration mode | Dedicated local server, RCON, **zero players connected** |

The workspace was created from the public `MobBy` repository at v1.1.0. No GitHub account was
connected and no commit, push, pull request or release was made.

## Build and unit tests

Commands (run from the project root):

```bash
export JAVA_HOME=$HOME/jdk21
export PATH="$JAVA_HOME/bin:$PATH"
./gradlew clean build --no-daemon --console=plain
./gradlew test --no-daemon --console=plain
```

| Command | Exit status | Result |
|---|---|---|
| `./gradlew clean build --no-daemon` | 0 | `BUILD SUCCESSFUL in 10s`; compiled, tested and produced `build/libs/MobBy-1.2.0.jar` |
| `./gradlew test --no-daemon` | 0 | `BUILD SUCCESSFUL in 11s`; 55 tests pass |

Test result XML totals: **55 tests, 0 failures, 0 errors, 0 skipped.**

| Test class | Tests | Notes |
|---|---:|---|
| `RegionBoundsTest` | 12 | preserved from 1.1.0 |
| `RegionTest` | 9 | preserved from 1.1.0 |
| `FurnaceMathTest` | 11 | preserved from 1.1.0 |
| `DurationFormatTest` | 6 | preserved from 1.1.0 |
| `SpawnRulesTest` | 13 | new in 1.2.0: magma/bedrock, dimension, light, headroom, wide-mob clearance, slime chunks/Y, animal light, liquid floors, caps, biome lists, normalisation |
| `SlimeChunksTest` | 4 | new in 1.2.0: determinism, ~10% distribution, negative coordinates, seed dependence |
| **Total** | **55** | 38 preserved + 17 new |

The integration runs used this exact delivered JAR (SHA-256 `a92afb69…a30fd`).

## Review pass

A second review of the spawn and unattended-AI path found and fixed these issues:

- `BoundingBox#expand` mutates the box in place. Recovery and cleanup now expand a `clone()`, so the
  runtime's `entityBounds` stays exactly the region and the all-entity cap does not silently cover
  nearby terrain, nor does the cleanup radius grow on every restart.
- A per-type value in `mob-caps` could exceed `max-mobs-per-region`. The effective cap is now
  `min(max-mobs-per-region, mob-caps[type])`, so a per-type entry can only tighten the cap.
- The all-entity cap was checked once before a cycle, so a cycle could overshoot it by up to
  `max-mobs-per-cycle` entities. The remaining entity room is now applied through the same
  `SpawnRules.allowance` helper as the mob cap.
- A failed `addPluginChunkTicket` previously left the region active with a partially loaded chunk set.
  Activation now releases every ticket it acquired and returns an error.
- If setup failed after `spawnEntity`, the untagged entity was left behind. It is now removed.
- Removed unused `SpawnRules.effectiveLightCap`, `SpawnContext.of`, `MobProfiles.isKnown`,
  `ServerCompat.activationRangeSummary` and the test that only covered the dead light-cap helper.

After these changes: **55 unit tests pass**, and the rebuilt JAR passed **36/36** live checks plus
**5/5** restart checks on Paper 26.3 build 253. An earlier exploratory run produced 34/36 because the
old test fixture's gold-farm region extended beyond its one-block walls and the crop sample used a
short window; the fixture was tightened to a fully walled region and a 90-second crop window, after
which the run was clean. No MobBy error appeared in any server log.

## Version verification

The delivered JAR was inspected directly:

| Location | Value |
|---|---|
| `build.gradle.kts` `version` | `1.2.0` |
| `src/main/resources/plugin.yml` `version` | `1.2.0` |
| JAR `plugin.yml` `version` | `1.2.0` |
| JAR `META-INF/MANIFEST.MF` `Implementation-Version` | `1.2.0` |
| JAR filename | `MobBy-1.2.0.jar` |
| README / CHANGELOG | 1.2.0 sections present |

`dist/MobBy-1.1.0.jar` is preserved unchanged. The 1.2.0 JAR is a new build with new classes, not a
renamed 1.1.0 JAR.

## Real Paper integration test — 36/36 checks passed

Script: `scripts/paper-1.2.0-integration-test.py`
Server: Paper 26.3 build 253, Java 25, normal Overworld + Nether, **no player ever connected**,
`spigot.yml` entity activation range 0, separate walled Nether region and open turtle-egg region.

| Check | Result |
|---|---|
| Plugin loads, `MobBy v1.2.0` in log, `/mobby help`, `/plugins` | pass |
| Compatibility profile: ticks, random ticks, snapshot inventory, love mode, recipe XP, `mob-aware=yes`, `pathfinder=yes` | pass |
| Sealed dark chamber (567 blocks, block light 0), 49 indexed floors | pass |
| 12 zombies spawned unattended with `mobby:managed` PDC tag | pass |
| Walled Nether roof magma farm: 12/12 piglins standing on magma, **0 on bedrock rim** | pass |
| Turtle egg region: 8/8 piglins walked to the egg ledge via pathfinding (8 within 2 blocks) | pass |
| Furnace: 3 raw iron + coal → exactly 3 iron ingots unattended | pass |
| Redstone piston fired unattended | pass |
| Crops: 4/16 sampled wheat above age 0 in 90 s | pass |
| Chunk tickets: held while active, 0 after stop, restored on start | pass |
| Uptime paused on stop; list, reload and unknown-region handling | pass |
| Clean shutdown, no MobBy errors, regions persisted ACTIVE | pass |

The individual assertions total **36/36 passed**. The server was then restarted with
`--restart-only` on the same world.

## Restart test — 5/5 checks passed

The same server was restarted with `--restart-only`:

| Check | Result |
|---|---|
| 4 regions resumed ACTIVE after restart | pass |
| Chunk tickets restored | pass |
| Uptime preserved (downtime not counted) | pass |
| No duplicate tasks after restart | pass |
| Clean shutdown | pass |

## What was not tested

- Interactive tab completion from a real client (RCON cannot send tab completion).
- Permission checks from a real non-op player, multiple simultaneous players, and custom worlds.
- Folia / region threading (not supported).
- Long-duration (hours) soak testing and TPS under load.
- The 1.20.6 / 1.21.1 / 1.21.4 / 1.21.8 matrix with the **1.2.0** JAR. Those versions passed with
  1.1.0; the 1.2.0 additions use the same guarded API surface but were not re-run there.
- Live creeper, skeleton, slime, spider and passive-animal farms. Their profiles are unit tested, but
  only the dark-room hostile farm, Nether magma gold farm and turtle-egg attraction were built on a
  live server.
- Full-speed mob movement with default Spigot entity activation ranges. The integration run used
  activation range 0; MobBy detects and reports the setting but does not edit server files.

## Compatibility statement

Confirmed by execution: Paper **26.3 build 253** with Java 25, no players, including the Nether gold
farm and turtle-egg pathfinding paths.

Not re-confirmed with 1.2.0 in this run: Paper 1.20.6-151, 1.21.1-133, 1.21.4-232 and 1.21.8-60. The
plugin is still compiled once against the Paper 1.20.6 API with Java 21 bytecode and uses the same
runtime guards, but the compatibility table in the README marks those as previously verified with
1.1.0, not as 1.2.0 measurements.

## Deliverables

| File | Purpose |
|---|---|
| `MobBy-1.2.0.jar` | ready-to-install plugin (also in `dist/`) |
| `MobBy-1.2.0-project.zip` | complete project: sources, Gradle wrapper, scripts, configs, docs, JARs |
| `SHA256SUMS-1.2.0.txt` | checksums for the JAR, project ZIP and preserved 1.1.0 JAR |
| `BUILD-AND-TEST-REPORT-1.2.0.md` | this report |
| `README.md`, `CHANGELOG.md` | updated for 1.2.0 |
