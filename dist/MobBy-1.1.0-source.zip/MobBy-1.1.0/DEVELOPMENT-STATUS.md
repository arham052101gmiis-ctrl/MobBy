# MobBy 1.1.0 release status

The official release derives from the validated 1.2.0-dev1 binary. The release and candidate hashes, entry-by-entry comparison, and new verification results are recorded in [the release test report](TEST-REPORT-1.1.0.md). The [soak report](SOAK-REPORT-1.1.0.md) records the evidence inherited from the candidate.
