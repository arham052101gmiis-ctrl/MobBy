# MobBy 1.1.0 release handoff

Use the Gradle wrapper from this source directory to reproduce the build. The README provides installation instructions. The distribution manifest checks the JAR, complete source archive and two reports.

For the functional and restart verification used for this release, build the plugin and bundled test probe, then run the following with a Java 25 executable and official Paper 26.3 build 256.

```sh
python3 scripts/paper-dev-integration.py --java "$JAVA25" --paper-jar "$PAPER" --evidence evidence/local-release-verification
```

Choose a fresh evidence directory for each run. The functional harness expects MobBy 1.1.0. The archived soak tools stay pinned to the candidate hash for which the original run was authorized. Historical candidate documents and raw results are included under `docs/history/1.2.0-dev1/` and `evidence/`. Fresh evidence is in `evidence/release-1.1.0/`.
