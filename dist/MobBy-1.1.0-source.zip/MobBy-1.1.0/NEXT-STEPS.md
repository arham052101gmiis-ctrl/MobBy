# MobBy 1.1.0 release scope

The release package is prepared for distribution. Publication requires the owner's approval. Future claims about higher region counts, mixed-plugin servers or additional Paper versions need measurements for those environments.
