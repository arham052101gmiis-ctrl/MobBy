# Candidate soak evidence for MobBy 1.1.0

See [Candidate soak evidence](SOAK-REPORT-1.1.0.md). The original candidate report is preserved in [the development archive](docs/history/1.2.0-dev1/SOAK-REPORT.md).
