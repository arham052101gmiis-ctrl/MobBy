# Development status · 2026-11-24

## 180-minute soak · attempt-01

Passed. Recorded 180.00 minutes in this one server lifetime, with 361 samples and 36 five-minute checkpoints.

## Soak launch record

The authorized 180-minute soak began at 23:58:22 Dubai time on 24 November. See the current run status in ../runs/attempt-01/status.json and the durable measurements in samples.jsonl.

## Validated development candidate

MobBy 1.2.0-dev1 passed 65 JVM tests, its Paper 26.3-256 functional/restart suite, an independent zero-player gold collection test and a 901.1-second four-region reliability run. Candidate SHA-256 is `413a57506f8328fe131d08bb514f0593cc388238234be4b6f71f40b1c412bb14`. Current reports and reproduction commands are in TEST-REPORT.md and HANDOFF.md. The attached checkpoint 2 remains the source of lineage. The 1.3.0 public-release milestone remains open.

## Archived checkpoint notes

Primary source is /workspace/MobBy-development/source. The milestone is 1.2.0-dev1 source reconstruction. Both 1.2.0 archive hashes and the internal dist hashes matched. The 55 baseline unit tests and 64 development unit tests passed using the standalone JUnit launcher and Java 21.

The full build is blocked before Java compilation while resolving Paper API (HTTP 403). Official server metadata for build 256 also returned HTTP 403. No candidate binary, integration pass, performance measurement or short reliability result is available. The long soak awaits separate approval after short reliability passes.

The environment configuration draft points setup and startup at this source. See HANDOFF.md for reproducible commands and NEXT-STEPS.md for the remaining gates.

## Continuation checkpoint · 24 November, 15:24 Dubai time

The running instance reported restricted egress, enforcement active and no custom hosts. The editable draft contained all five requested custom hosts. Each HTTPS proxy tunnel returned 403. Gradle's offline build confirmed that the Paper API snapshot is absent from its cache. Java 25.0.5+8 executed successfully.

Changes in this checkpoint are confined to integration tooling, Gradle test-fixture wiring, evidence and recovery documents. See TEST-REPORT.md for the instrument and harness checks. The prior source archive has been retained. The updated archive is MobBy-1.2.0-dev1-source-checkpoint2.zip.
