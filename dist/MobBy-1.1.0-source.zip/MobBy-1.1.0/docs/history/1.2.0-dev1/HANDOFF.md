# Continuing development

## 180-minute soak · attempt-01

Run attempt-01. Consult SOAK-REPORT.md and evidence/soak/attempt-01/. To inspect a surviving run use scripts/soak-results.py with its evidence directory. A new run always requires a fresh ID. Keep partial and complete runs separate.

## Soak launch record

The authorized long-run workspace is /workspace/checkpoint2-dev/soak180. The validated distribution remains in ../deliverables/validated-dev1 relative to that workspace. Inspect the live monitor before any launch with python3 scripts/soak-results.py ../runs/attempt-01 from this source tree. Identity checks use the boot ID, PID and OS process start ticks. Each new attempt has an exclusive evidence directory. Evidence survives independently of the generated world.

## Resume this candidate

Start in the source directory containing build.gradle.kts. Check the distribution SHA256SUMS.txt before extracting the ZIP. Its source archive includes all Java sources, Gradle wrapper, test fixtures, maintained documents and compact evidence. The workspace copy is /workspace/checkpoint2-dev/MobBy-1.2.0-dev1.

Build with a JDK 21+ and `bash gradlew --no-daemon --max-workers=2 build`. The published environment used Java 25 at /tmp/mobby/jdk-25.0.5.1 and GRADLE_USER_HOME=/tmp/mobby/gradle. The managed HTTPS proxy required the environment proxy host/port and the CA truststore /etc/ssl/certs/java/cacerts as JVM options. Temp tools may need downloading in a new instance. Fetch the official server using the URL in evidence/official-paper-build256.json and verify the SHA-256 in evidence/artifact-verification.txt.

Run these commands with fresh evidence directories from the extracted source, with JAVA25 pointing to the Java executable and PAPER to the verified server JAR.

```bash
python3 scripts/paper-gold-output.py --java "$JAVA25" --paper-jar "$PAPER" --evidence evidence/gold-new
python3 scripts/paper-dev-integration.py --java "$JAVA25" --paper-jar "$PAPER" --evidence evidence/paper-new --short-reliability
```

Run the second command after the gold-collection checks have passed. The main suite automatically gates the 15-minute phase on its own functional, restart, shutdown and log checks. The probe belongs exclusively to temporary fixtures. The release candidate is the MobBy JAR under build/libs. See TEST-REPORT.md for evidence and NEXT-STEPS.md for authorization-dependent work.

## Archived checkpoint notes

Use the source tree containing this file. In the original cloud instance this is /workspace/MobBy-development/source. The sibling handoff directory holds the complete 1.2.0 ZIP and JAR, late dev7 documents, checksums and interrupted-soak notes. The previous desktop and GitHub checkout were outside this development tree. The archived .git file pointed at a different workspace and was excluded from the extracted development copy.

Original upload SHA-256 is c8cff17aa7aa5d635bfef131666666d91b96e9a34e7cafaaf8765b1f4f12375d. Foundation source ZIP SHA-256 is b59523484bf2900ec3e38e210e3736447eafb4fed81b5c83f82ec293da3aa274. Foundation JAR SHA-256 is a92afb6905c6b02139326338969b9e3ba18f347cfb46f050de51ec05ee8a30fd. No dev7 binary or source was used. The later documentation informed the reconstruction.

## Build in the cloud instance

```bash
cd /workspace/MobBy-development/source
export JAVA_HOME=/workspace/.mobby-jdk-21.0.13.1
export GRADLE_USER_HOME=/workspace/.mobby-gradle
export JAVA_OPTS="-Dhttps.proxyHost=proxy -Dhttps.proxyPort=8080 -Dhttp.proxyHost=proxy -Dhttp.proxyPort=8080"
bash gradlew --no-daemon --max-workers=4 build
```

The independent JVM tests can also be run using scripts/unit-standalone.py --junit PATH_TO_JUNIT_JAR. Use the Maven Central JUnit Platform Console Standalone 1.11.4 JAR. This compiles the tests and the production classes they exercise.

## Run the real-server gate

Obtain Paper 26.3 build 256 from the official Paper downloads service. Verify the server JAR against the official build metadata and the build-256 fingerprint enforced by the harness. Use the built dev1 plugin. If the Java runtime needs the cloud proxy for the initial Mojang download, pass the same HTTPS proxy host and port through JAVA_TOOL_OPTIONS when starting the harness. Python requires 3.11 or newer. On this instance the target JDK is /workspace/MobBy-development/tools/jdk-25.0.5+8.

```bash
python3 scripts/paper-dev-integration.py --java /workspace/MobBy-development/tools/jdk-25.0.5+8/bin/java \
  --paper-jar /path/to/paper-26.3-256.jar --plugin-jar build/libs/MobBy-1.2.0-dev1.jar \
  --short-reliability --evidence ../evidence/paper-dev1-run-01
```

Use a fresh evidence directory on each run. The runner uses two loopback ports, a temporary world and a generated RCON password. It records the artifact hashes, individual assertions, console and Paper logs. During the 15-minute sampling phase it also records TPS, MSPT and JVM heap observations. Review results and diagnose any failure before claiming the target works. On another machine pass its local Java executable and use python or py as appropriate. Do not run the 180-minute soak without the user's approval.

## Network and runner checkpoint

In cloud environment settings, open the MobBy environment, keep restricted internet access and its package-manager preset, and save/apply the five custom hosts from the existing draft to the running instance. The hosts are repo.papermc.io and artifactory.papermc.io for build dependencies, fill.papermc.io and fill-data.papermc.io for the official build and server artifact, and piston-data.mojang.com for Paper's vanilla server dependency. The running policy reported no custom hosts at the last check. Resume dependency resolution once the policy changes.

Verify the server fingerprint in scripts/paper-dev-integration.py against the official build metadata's downloads.server:default.checksums.sha256. A successful Gradle build should produce the candidate in build/libs and the test-only MobBy-test-probe.jar in build/paper-fixtures. The latter belongs only in the harness's temporary test world. The existing harness command locates it automatically when run from the source directory.

The runner journals completed assertions to checks.jsonl. The functional server shuts down, the persisted world restarts and its logs are checked before an optional third boot for 15 minutes of reliability sampling. The reliability directory should contain performance.jsonl with raw TPS, MSPT and JVM heap readings, server-cpu.jfr and cpu.jsonl with JFR user/system CPU load. CPU values are fractions of available machine CPU capacity. Examine variation over the full interval, workload continuity and errors before drawing a stability conclusion.
