# Remaining work

## 180-minute soak · attempt-01

Review the monitored workload and its coverage before broader release testing. Other Paper versions and mixed-plugin production loads need separate validation.

## Soak launch record

Check the existing process identities and timestamps before taking any recovery action. The separate report writer waits for the monitor and builds the final distribution. Preserve an interrupted run with its original ID and elapsed duration.

## After the 1.2.0-dev1 candidate

The requested Paper 26.3-256 short-run gates are complete. The 180-minute soak requires separate approval. Use the recorded candidate hash and repeat performance sampling with representative region counts and farm designs before making a production-capacity or long-term stability claim. Older Paper versions, generic species outside the named profiles, additional redstone designs and mixed-plugin servers need their own evidence before broad compatibility claims. Publication and remote repository changes require approval.
